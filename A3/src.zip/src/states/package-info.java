/**
 * Contains the definition of the Broker, Spectator, and Horse/Jockey entity states.
 */
package states;
