/**
 * Contains the definition of the Paddock server.
 */
package serverSide.paddock;