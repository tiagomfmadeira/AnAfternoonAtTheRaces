/**
 * Contains the definition of the Control Center server.
 */
package serverSide.controlCenter;