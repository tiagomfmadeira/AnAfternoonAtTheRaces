/**
 * Contains the definition of the Betting Center server.
 */
package serverSide.bettingCenter;
