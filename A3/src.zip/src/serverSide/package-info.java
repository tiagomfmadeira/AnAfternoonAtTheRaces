/**
 * Contains the definition of the shared memory regions and server-side protocol.
 */
package serverSide;
