/**
 * Contains the definition of the Spectator entity.
 */
package clientSide.spectator;
