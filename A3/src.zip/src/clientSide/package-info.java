/**
 * Contains the definition of the entities.
 */
package clientSide;
