/**
 * Contains the definition of the settings of the servers.
 */
package settings;
