/**
 * Contains the definition of the register and the interfaces available from objects representing the memory sharing regions
 */
package interfaces;
