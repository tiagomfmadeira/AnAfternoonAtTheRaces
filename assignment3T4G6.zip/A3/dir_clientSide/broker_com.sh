#!/usr/bin/env bash
java clientSide.broker.BrokerMain
