#!/usr/bin/env bash
java clientSide.horseJockey.HorseJockeyMain
