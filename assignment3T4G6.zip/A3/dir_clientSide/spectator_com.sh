#!/usr/bin/env bash
java clientSide.spectator.SpectatorMain

