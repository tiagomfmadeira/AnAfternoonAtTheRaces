/**
 * Contains the definition of the General Repository server.
 */
package serverSide.generalRepository;
