/**
 * Contains the definition of the Stable server.
 */
package serverSide.stable;