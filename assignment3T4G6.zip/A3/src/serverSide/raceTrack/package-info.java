/**
 * Contains the definition of the Race Track server.
 */
package serverSide.raceTrack;