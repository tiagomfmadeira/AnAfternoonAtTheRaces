/**
 * Contains the definition of the Horse/Jockey entity.
 */
package clientSide.horseJockey;