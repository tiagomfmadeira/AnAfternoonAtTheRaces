/**
 * Contains the definition of the Broker entity.
 */
package clientSide.broker;
