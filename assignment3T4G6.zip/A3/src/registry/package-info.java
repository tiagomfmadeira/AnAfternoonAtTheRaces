/**
 *  Contains the definition of the protocol for registration of remote objects in the local registry service.
 *  The communication is based in Java RMI.
 */
package registry;
